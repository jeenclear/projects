<?php
/*
Plugin Name: PL PD OPP
Description: Just another plugin form Plonta Creative.
Version: 1
Author: Plonta Creative
Author URI: http://plontacreative.com/
*/


error_reporting(E_ALL);

define( 'PL_PD_OPP_BASEPATH',  dirname(__FILE__) );

define( 'PL_PD_OPP_LIB', PL_PD_OPP_BASEPATH . '/lib' );

define( 'PL_PD_OPP_VIEWS', PL_PD_OPP_BASEPATH . '/views' );

define( 'PL_PD_OPP_JS', PL_PD_OPP_BASEPATH . '/js' );

define( 'PL_PD_OPP_SHORTCODE', PL_PD_OPP_BASEPATH . '/shortcode' );


if( ! class_exists('PL_pd_opp_Bootstrap') ) {
   
   if(! class_exists('PL_pd_opp_Loader') ) { 
      require PL_PD_OPP_LIB . '/PL_pd_opp_Loader.php';
   } 
   
   if(! class_exists('PL_pd_opp_Lib') ) { 
      require PL_PD_OPP_LIB . '/PL_pd_opp_Lib.php';
   } 
   
   if(! class_exists('PL_pd_opp_Query') ){
      require PL_PD_OPP_LIB . '/PL_pd_opp_Query.php';
   }  
   
}

 require 'PL_pd_opp_Bootstrap.php'; 

 $PL_pd_opp_Bootstrap = new PL_pd_opp_Bootstrap();

?>