<?php

if(! class_exists('PL_PD_OOPP_Shortcode_ui') ) {          
    
  class PL_PD_OOPP_Shortcode_ui{
     
     public function __contruct(){  
     }
     
     public function pl_pd_opp_shortcode(){
          
       $tbl = $wpdb->prefix . PL_pd_opp_Lib::$tbl_var;
          
       $query = PL_pd_opp_Query::Query( 'g_position', $tbl );
       
       $html .= '';
       $html .= '<div id="PL_pd_opp">';
       $html .= '<div id="PL_pd_opp_wrap">';
           
      foreach( $query as $pl_pd_opp => $pl_pd_opp_content ){ 
          
          $html .= '<div id="Pl_pd_opp_'.$pl_pd_opp_content->id.'" class="PL_pd_opp_ui">';
          
          $html .= '<div class="accordion-content-wrap">';
          
          $html .= '<h2>'.$pl_pd_opp_content->name.'</h2>';      
              
          $html .= '<div class="accordion-text">';
          $html .= $pl_pd_opp_content->details;
          $html .= '</div>';
          
          $html .= '<div class="accordion-image"><a target="_blank" href="'.$pl_pd_opp_content->brochure.'"><img src="'.$pl_pd_opp_content->img.'" /></a></div>';
          
          $html .= '<div class="accordion-price">';
          
          if( $pl_pd_opp_content->cost != '' ){
            
            $html .= '<div class="cost-price">Cost: <strong>'.$pl_pd_opp_content->cost.'</strong></div>'; 
            
          }else{
            
            //$html .= 'Cost is based on a flat fee'; 
            $html .= '<div class="cost-price trans">Cost</div>'; 
            
          }
          
          $html .= '<a class="accordion-dow-btn" target="_blank" href="'.$pl_pd_opp_content->brochure.'">Brochure</a>';
          $html .= '<a class="accordion-reg-btn" target="_blank" href="'.$pl_pd_opp_content->reg_link.'">Register</a>';
          $html .= '</div>';
          
          $html .= '</div>';
      
          $html .= '</div>';
      }    
       
       $html .= '</div>';   
       $html .= '</div>';
       return $html;
        
     }
     
   }  

}   
?>
