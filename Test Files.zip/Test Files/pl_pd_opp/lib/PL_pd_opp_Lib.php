<?php
  class PL_pd_opp_Lib{
     
     public static $tbl_var = 'pl_pd_opp';
     
     public static function insert_pl_pd_opp(){
     
        global $wpdb;
        
        $tbl = $wpdb->prefix . PL_pd_opp_Lib::$tbl_var;
        
        $input = (object)array( 'post' => (object)$_POST, 'get'  => (object)$_GET );
        
        if( isset( $input->post->add_pl_pd_opp ) ){
            
            $title   = trim( stripslashes_deep( $input->post->pl_pd_opp_title ) );
            $cost   = trim( stripslashes_deep( $input->post->pl_pd_opp_cost ) );
            $reg_link   = trim( stripslashes_deep( $input->post->pl_pd_opp_reg_link ) );
            
            $image   = trim( stripslashes_deep( $input->post->image ) );
            $file   = trim( stripslashes_deep( $input->post->file ) );
            
            $allowed_html_desc = array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'div' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'span' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'label' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'p' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h1' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h2' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h3' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h4' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'code' => array(),
                    'br' => array(),
                    'em' => array(),
                    'b' => array(),
                    'strong' => array()
                );
     
            if( !empty( $title ) ){
                  
                        $wpdb->insert(
                                    	$tbl,
                                    	array(  
                                    		'name' => $title,
                                            'details' =>  $input->post->pl_pd_opp_details,                                            
                                            'cost' => $cost,
                                            'img' => $image,
                                            'brochure' => $file,
                                            'reg_link' => $reg_link
                                    	),
                                    	array(
                                    		'%s',
                                    		'%s',
                                            '%s',
                                            '%s',
                                            '%s',
                                            '%s'
                                    	)
                                    );

              }
          
        }
        
     }
     
     
     public static function my_ajax_update_pl_pd_opp_tbl(){
     
        global $wpdb;
        
        $tbl = $wpdb->prefix . PL_pd_opp_Lib::$tbl_var;
        
        $input = (object)array( 'post' => (object)$_POST, 'get'  => (object)$_GET );
        
        if( isset( $_POST['action'] ) ){
            
            $id   = trim( stripslashes_deep( $input->post->id ) );
            $name   = trim( stripslashes_deep( $input->post->name ) );
            $details   = trim( stripslashes_deep( $input->post->details ) );
            $cost   = trim( stripslashes_deep( $input->post->cost ) );
            $reg_link   = trim( stripslashes_deep( $input->post->reg_link ) );
            
            $img   = trim( stripslashes_deep( $input->post->img ) );
            $brochure   = trim( stripslashes_deep( $input->post->brochure ) );
            
            $allowed_html_desc = array(
                    'a' => array(
                        'href' => array(),
                        'title' => array()
                    ),
                    'div' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'span' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'label' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'p' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h1' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h2' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h3' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'h4' => array(
                        'class' => array(),
                        'id' => array()
                    ),
                    'code' => array(),
                    'br' => array(),
                    'em' => array(),
                    'b' => array(),
                    'strong' => array()
                );
            
            if( !empty( $name ) ){
                    
                       $id_ = intval( $id );
                       
                       $wpdb->update(
                                        $tbl,
                                        array(
                                    		'name' => $name,
                                            'details' =>  $details,                                            
                                            'cost' => $cost,
                                            'img' => $img,
                                            'brochure' => $brochure,
                                            'reg_link' => $reg_link
                                    	),
                                        array(
                                    		'id' => $id_,
                                    	), 
                                        array(
                                    	    '%s',
                                    		'%s',
                                            '%s',
                                            '%s',
                                            '%s',
                                            '%s'
                                    	),
                                        array(
                                    		'%d'
                                    	)  
                                    );
                          
                       
              }
          
        }
        
     }
     
    public static function delete_pl_pd_opp(){
        global $wpdb;
        
        $tbl = $wpdb->prefix . PL_pd_opp_Lib::$tbl_var;
        
        $input = (object)array( 'post' => (object)$_POST, 'get'  => (object)$_GET );
        
        if( isset($input->post->delete_pl_pd_opp) ){
            
          if( !empty( $input->post->delete_selected ) ){  
            $delete_all = $input->post->delete_selected;
            
            if( is_array( $delete_all ) ){
                
                    foreach( $delete_all as $all => $delete){
                        
                              $id = intval( $delete_all[$all] );  
                              
                              $wpdb->delete( 
                                               $tbl, 
                                               array( 'id' => $id ), 
                                               array( '%d' ) 
                                           );  
                    }
            }
            
            wp_redirect( 'admin.php?page=PL_PD_OPPmanager', 301 );
            exit;
           } 
            
        } 
                                     
    }
   
  
    public function my_ajax_sort_update_pl_pd_opp_sort(){
        global $wpdb;

        $tbl = $wpdb->prefix . PL_pd_opp_Lib::$tbl_var;
        $input = (object)array( 'post' => (object)$_POST, 'get'  => (object)$_GET );
        
        $g_id = $input->post->id_group;
        $g_position = $input->post->id_value;
        
        $count = 1;
        if(!empty($g_position)){
            
            $clean_g_position = explode(',', $g_position);
            
            if(!empty($clean_g_position)){
                
                foreach( $clean_g_position as $clean_g_position_key => $clean_g_position_val ){

                       $wpdb->update(
                                        $tbl,
                                        array( 'g_position' => $count++ ),
                                        array( 'id' => $clean_g_position_val ), 
                                        array( '%d' ),
                                        array( '%d' )  
                                     );
                                            
                } 
            }
        }
        
        die();             
   }
   
     
  }
  
?>