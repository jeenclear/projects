<?php
   
   class PL_pd_opp_Query{
        
        public static function Query($position, $db_tb){
            global $wpdb;
            $tbl = $wpdb->prefix . $db_tb;
            
            $query = $wpdb->get_results("SELECT * FROM $tbl ORDER BY `$position` ASC");
            if( is_array($query)) return $query;
        }
        
        
        public static function Querytb($db_tb){
            global $wpdb;
            $tbl = $wpdb->prefix . $db_tb;
            
            $query = $wpdb->get_results("SELECT * FROM $tbl");
            if( is_array($query)) return $query;
        }
        
        public static function QueryRow($id=0, $id_name, $db_tb){
            global $wpdb;
            $tbl = $wpdb->prefix . $db_tb;
            
            $id_val = intval($id); 
            
            if( !is_null($id_val) AND 
                    $id_val != 0 ){
                    
                    $row = $query = $wpdb->get_row("SELECT * FROM $tbl WHERE $id_name={$id_val}");
                    if( is_object($row)) return $row;
                         
            }
        }
        
        public static function Querymatch($id=0, $id_name, $db_tb, $pos=''){
            global $wpdb;
            $tbl = $wpdb->prefix . $db_tb;
            
            $id_val = intval($id); 
                    $query = $wpdb->get_results("SELECT * FROM $tbl WHERE $id_name={$id_val}");
                    if( is_array($query)) return $query;
        }
        
        public static function Querymatch_sort($id=0, $id_name, $db_tb, $pos=''){
            global $wpdb;
            $tbl = $wpdb->prefix . $db_tb;
            
            $sort = "ORDER BY `$pos` ASC";
            
            $id_val = intval($id); 
                    $query = $wpdb->get_results("SELECT * FROM $tbl WHERE $id_name={$id_val} $sort");
                    if( is_array($query)) return $query;
        }
        
        public static function QueryField($id=0, $field=null, $db_tb){
            global $wpdb;
            $tbl = $wpdb->prefix . $db_tb;
            
            $id_val = intval($id); 
            
            if( !is_null($field) AND !empty($field)){
                 $field_value = $field;
            } else {
                 $field_value = "*";
            }
            
            if( !is_null($id_val) AND 
                    $id_val != 0 ){
                    
                    $row = $query = $wpdb->get_row("SELECT $field_value FROM $tbl WHERE id={$id_val}");
                    if( is_object($row)) return $row;
                         
            }
        }
        
      public static function fetch_max($id, $tbl){
       global $wpdb;
       $return = $wpdb->get_results(  "SELECT max($id) as max_id FROM ".$wpdb->prefix . $tbl ); 
       
       $max_return_id = array();
       if( is_array( $return ) > 0){
    
           foreach( $return as $return_row => $return_array ){
                  if( $return_array->max_id  ):
                       $max_return_id[] = $return_array->max_id ;  
                  endif;
           }
       }
       return $max_return_id;
     }
    
   }
   
?>