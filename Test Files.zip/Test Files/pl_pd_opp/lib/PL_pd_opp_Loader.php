<?php
  class PL_pd_opp_Loader{
      
      public static $icon = '<div id="pl_pd_opp_icon" class="icon"><br /></div>';
      
      public function manage_pl_pd_opp(){
        require PL_PD_OPP_VIEWS . '/manage_pl_pd_opp.php';
      }
      
      public function add_new_pl_pd_opp(){
        require PL_PD_OPP_VIEWS . '/add_new_pl_pd_opp.php';
      }
      
      public function edit_pl_pd_opp($id){
        require PL_PD_OPP_VIEWS . '/edit_pl_pd_opp.php';
      }
      
      public function pl_pd_opp_shortcode(){
        require PL_PD_OPP_SHORTCODE . '/pl_pd_opp_shortcode.php';
      }
      
      public static function upload_button_image($image){
    ?>        
        <div class="gallery_image_container">
            <input type="text" class="gallery_image_text" id="gallery_image_text" name="image" value="<?php echo $image; ?>" />
            <input id="gallery_image_browse" class="button secondary-button" type="submit" value="Browse..." name="gallery_image_browse" aria-required="true" />
        </div>
        <?php
         if( $image != '' ){
            
          $parse_url = parse_url( $image );
          if( $parse_url['scheme'] == 'http' OR $parse_url['scheme'] == 'https' ){
               $display = 'display: block;';
          } else {
               $display = 'display: none;';
          }
         
         }else{ 
               $display = 'display: none;';
         }
          
          $explode_images = explode('/', $image );
          $end_name = end($explode_images);
          
        ?>
        <div class="gallery_image_display" style="<?php echo $display; ?>">
            <div class="gallery_image_display_img_content"><img src="<?php echo $image; ?>" id="gallery_image_display_img" class="gallery_image_display_img" /></div>
            <span class="gallery_image_display_remove">x</span>
            <span class="gallery_image_display_label"><?php echo $end_name; ?></span>
        </div>
       
    <?php
     }
     
         public static function upload_button_file($file){
    ?>        
        <div class="gallery_file_container">
            <input type="text" class="gallery_file_text" id="gallery_file_text" name="file" value="<?php echo $file; ?>" />
            <input id="gallery_file_browse" class="button secondary-button" type="submit" value="Browse..." name="gallery_file_browse" aria-required="true" />
        </div>
        <?php
         if( $file != '' ){
            
          $parse_url = parse_url( $file );
          if( $parse_url['scheme'] == 'http' OR $parse_url['scheme'] == 'https' ){
               $display = 'display: block;';
          } else {
               $display = 'display: none;';
          }
         
         }else{ 
               $display = 'display: none;';
         }
          
          $explode_images = explode('/', $file );
          $end_name = end($explode_images);
          
        ?>
        <div class="gallery_file_display" style="<?php echo $display; ?>">
            <span class="gallery_file_display_remove">x</span>
            <span class="gallery_file_display_label"><?php echo $end_name; ?></span>
        </div>
       
    <?php
     }
      
      public static function pl_pd_opp_database() {
        global $wpdb;
            
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        
        $table_pl_pd_opp = $wpdb->prefix . "pl_pd_opp"; 
        
        $sql1 = "CREATE TABLE $table_pl_pd_opp (
           id mediumint(9) NOT NULL AUTO_INCREMENT,
           name text NOT NULL,
           details text NOT NULL,
           cost text NOT NULL,
           img text NOT NULL,
           brochure text NOT NULL,
           reg_link text NOT NULL,
           g_position int(10) NOT NULL,
           UNIQUE KEY id (id)
        );";
      
        dbDelta( $sql1 );
        
   }
  
  }
?>