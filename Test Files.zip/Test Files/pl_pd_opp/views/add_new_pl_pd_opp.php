<?php
     $input = (object)array( 'post' => (object)$_POST,
                             'get'  => (object)$_GET );   

if( !isset( $input->get->pd_opp ) ){
    
     if( isset( $input->post->add_pl_pd_opp ) ){ 
          
          if( !empty( $input->post->pl_pd_opp_title ) ){
              $error1 = '';  
          }else{
              $error1 = '<div class="pweblinks_message_box">Pls. add name</div>'; 
              $success = '';
          }
          
          $title = $input->post->pl_pd_opp_title;
          $details = $input->post->pl_pd_opp_details;
          $cost = $input->post->pl_pd_opp_cost;
          $reg_link = $input->post->pl_pd_opp_reg_link;
          
          if( !empty( $input->post->pl_pd_opp_title ) ){
                 $success = '<div class="pweblinks_success_msg">Successfully Saved</div>';
                 $title = '';
                 $details = '';
                 $cost = '';
                 $reg_link = '';
          }
                    
     }else{
        
          $title = '';
          $details = '';
          $cost = '';
          $reg_link = '';
         
         $error1 = '';  
         $error2 = ''; 
         $success = '';
     
     }  
?>
  
<div class="pweblinks_wrap_titles">  
    <?php echo PL_pd_opp_Loader::$icon; ?>                     
    <div class="pweblinks_title">
           <h2 class="title"><?php echo isset( $input->get->pd_opp ) ? 'Edit' : 'Add New'; ?> Opportunity</h2>
    </div>
</div>
         <?php
           if($success != ''){
              print $success;
           }
        ?>
<div class="add_form_wrap">
        
   <div id="add-form">
        <form method="post">
        
          <label>Name</label>
           <p>
               <input id="pl_pd_opp_title" type="text" name="pl_pd_opp_title" value="<?php print $title; ?>" aria-required="true" />
               <?php print $error1; ?>
           </p>
           
           <label>Details</label>
           <p>
                <textarea name="pl_pd_opp_details" id="pl_pd_opp_details"><?php echo $details; ?></textarea>
                <br />
                <code>Accepts HTML tags</code>
           </p>
           
           <label>Cost</label>
           <p> 
                <input id="pl_pd_opp_cost" type="text" name="pl_pd_opp_cost" value="<?php print $cost; ?>" aria-required="true" />
           </p>
           
           <label>Brochure Image</label>
           <p> 
                <?php PL_pd_opp_Loader::upload_button_image(); ?>
           </p>
           
           <label>Brochure</label>
           <p> 
                <?php PL_pd_opp_Loader::upload_button_file(); ?>
           </p>
          
          <label>Registration Link</label>
           <p> 
                <input id="pl_pd_opp_reg_link" type="text" name="pl_pd_opp_reg_link" value="<?php print $reg_link; ?>" aria-required="true" />
          </p>

          <div id="add-submit">
            <?php $value_submit = isset( $input->get->pwl_id ) ? 'Save' : 'Submit'; ?>
            <input id="pl_pd_opp_submit" class="button button-primary" type="submit" name="add_pl_pd_opp" value="<?php echo $value_submit; ?>" /></td>
         </div>
         
       </form>
   </div>
   
</div> 

<?php
  }else{ 
?>   
  
  <div class="pweblinks_edit_form">
   <?php  PL_pd_opp_Loader::edit_pl_pd_opp($id); ?>
  </div>
  
<?php
 }
?>