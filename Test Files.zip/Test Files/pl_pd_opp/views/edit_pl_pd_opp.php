<?php
     $input = (object)array( 'post' => (object)$_POST,
                             'get'  => (object)$_GET );   

    
     if( isset( $input->post->add_pl_pd_opp ) ){ 
          
          if( !empty( $input->post->pl_pd_opp_title ) ){
              $error1 = '';  
          }else{
              $error1 = '<div class="pweblinks_message_box">Pls. add name</div>'; 
              $success = '';
          }
          
          $title = $input->post->pl_pd_opp_title;
          $details = $input->post->pl_pd_opp_details;
          $cost = $input->post->pl_pd_opp_cost;
          $reg_link = $input->post->pl_pd_opp_reg_link;
          
          if( !empty( $input->post->pl_pd_opp_title ) ){
                 $success = '<div class="pweblinks_success_msg">Successfully Saved</div>';
                 $title = '';
                 $details = '';
                 $cost = '';
                 $reg_link = '';
          }
                    
     }else{
        
          $title = '';
          $details = '';
          $cost = '';
          $reg_link = '';
         
         $error1 = '';  
         $error2 = ''; 
         $success = '';
     
     }  
?>

        
  <?php
     $id = $input->get->pd_opp;
     if( isset( $id ) ){
        
      $queryrow = PL_pd_opp_Query::QueryRow( $id, 'id', 'pl_pd_opp' );
         $value_row = array( 
                        'id' => $queryrow->id,
                        'name' => $queryrow->name, 
                        'details' => $queryrow->details, 
                        'cost' => $queryrow->cost,
                        'img' => $queryrow->img,
                        'brochure' => $queryrow->brochure,
                        'reg_link' => $queryrow->reg_link,
                        );
       
       }else{
         
          $row = Null;
          $value_row = array(
                      'id' => Null,
                      'name' => Null, 
                      'details' => Null, 
                      'cost' => Null,
                      'img' => Null,
                      'brochure' => Null,
                      'reg_link' => Null,
                     );
          
      }
  ?>      
  
    <script type="text/javascript">
        jQuery(function(){
            
                  /********************* Update PL_pd_opp **********************************/  
                         
                  jQuery('input#pl_pd_opp_submit').on('click', function(e){
                              e.preventDefault();
                              
                              var form = jQuery(this).parent().parent();
                              
                              /************** Info Fields ***************/
                              var pl_pd_opp_id = form.find('input#pl_pd_opp_id').val();
                              var pl_pd_opp_title = form.find('input#pl_pd_opp_title').val();
                              var pl_pd_opp_details = form.find('textarea#pl_pd_opp_details').val();
                              var pl_pd_opp_cost = form.find('input#pl_pd_opp_cost').val();
                              var gallery_image_text = form.find('input#gallery_image_text').val();
                              var gallery_file_text = form.find('input#gallery_file_text').val();
                              var pl_pd_opp_reg_link = form.find('input#pl_pd_opp_reg_link').val();
                              
                              if( pl_pd_opp_title != ''){
                                
                                    jQuery.ajax({
                                            type: "post", 
                                            url : ajaxurl, 
                                            data: { action : 'my_ajax_update_pl_pd_opp',
                                                    id : pl_pd_opp_id,
                                                    name : pl_pd_opp_title,
                                                    details : pl_pd_opp_details,
                                                    cost : pl_pd_opp_cost,
                                                    img : gallery_image_text,
                                                    brochure : gallery_file_text,
                                                    reg_link : pl_pd_opp_reg_link       
                                                  },
                                            beforeSend : function(){
                                                jQuery('.edit_form_wrap .pweblinks_loading').css( 'display', 'inline-block' );
                                            },
                            		        success: function(html, data){ //so, if data is retrieved, store it in html
                                                jQuery('.pweblinks_edit_form .edit_form_wrap .pweblinks_loading').css( 'display', 'none' );
                                                jQuery( ".pweblinks_edit_form .edit_form_wrap" ).prepend( "<div class='pweblinks_success_msg'>Successfully Updated</div>" );

                                            } 
                                      }).done(function(){
                                          //window.location.reload();
                                      }); 
                              }   
                     });
                     
                      /********************* Edit Update PL_pd_opp **********************************/  
                 });
     </script>
   
   <div class="pweblinks_wrap_titles">  
    <?php echo PL_pd_opp_Loader::$icon; ?>                                     
   <div class="pweblinks_title">
       <h2 class="title"><?php echo isset( $input->get->pd_opp ) ? 'Edit' : 'Add New'; ?> Opportunity</h2>
   </div>
   </div>
     
  <div class="edit_form_wrap">  
   <div id="add-form">
        <form method="post">
           
          <label>Name</label>
           <p>
                <input type="hidden" name="pl_pd_opp_id" id="pl_pd_opp_id" value="<?php print $value_row['id']; ?>" />
               <input id="pl_pd_opp_title" type="text" name="pl_pd_opp_title" value="<?php print $value_row['name']; ?>" aria-required="true" />
               <?php print $error1; ?>
           </p>
           
           <label>Details</label>
           <p>
                <textarea name="pl_pd_opp_details" id="pl_pd_opp_details"><?php echo $value_row['details']; ?></textarea>
                <br />
                <code>Accepts HTML tags</code>
           </p>
           
           <label>Cost</label>
           <p> 
                <input id="pl_pd_opp_cost" type="text" name="pl_pd_opp_cost" value="<?php print $value_row['cost']; ?>" aria-required="true" />
           </p>
           
           <label>Brochure Image</label>
           <p> 
                <?php PL_pd_opp_Loader::upload_button_image($value_row['img']); ?>
           </p>
           
           <label>Brochure</label>
           <p> 
                <?php PL_pd_opp_Loader::upload_button_file($value_row['brochure']); ?>
           </p>
          
          <label>Registration Link</label>
           <p> 
                <input id="pl_pd_opp_reg_link" type="text" name="pl_pd_opp_reg_link" value="<?php print $value_row['reg_link']; ?>" aria-required="true" />
          </p>

          <div id="add-submit">
            <?php $value_submit = isset( $id ) ? 'Save' : 'Submit'; ?>
            <input id="pl_pd_opp_submit" class="button button-primary" type="submit" name="edit_pl_pd_opp" value="<?php echo $value_submit; ?>" />
             <span class="pweblinks_loading"></span>
           
         </div>
         
      </form>
   </div>
   
</div>    