      <?php
        $input = (object)array( 'post' => (object)$_POST,
                                'get'  => (object)$_GET ); 
      ?>  
        
       <div class="pweblinks_wrap_titles">  
       <?php echo PL_pd_opp_Loader::$icon; ?>                     
       <div class="pweblinks_title">
           <h2 class="title">Manage Prof. Dev't Opportunities <a class="add_new_pweblinks" href="admin.php?page=PL_PD_OPP_add">Add New</a></h2>
            <p class="label-title">Manage your weblinks and arrange it, using sortable.</p>
       </div>
       </div>
        
        <div class="clear"></div>   
        
        <?php 
           $checkbox = '<input type="checkbox" class="delete_all" id="delete_all" name="delete_all" />';
           $label = array( $checkbox, 'Name', 'Cost', 'Image', 'Sort', '--'); 
        ?>
        
        <script type="text/javascript">
        jQuery(function(){
               
            jQuery('table#list-table').sortable({
                    
                                   items: 'tr.sort_tr',
                                   connectWith: 'table.ui-sortable',
                                   stop: function(event, ui){
                                         
                                         var id = [];
                                         jQuery('input.sort_id').each( function() {
                                                      if( jQuery(this) ){
                                                          var id_val = jQuery(this).attr('value');
                                                          id.push( id_val );
                                                      }
                                         });
                                         
                                         
                                         var id_join = id.join(',');
                                         var g_id    = jQuery('input.g_id').attr('value');
                                         //my_ajax_sort_update_pl_pd_opp_id
                                         jQuery.ajax ({
                                                        data: { action : 'my_ajax_sort_update_pl_pd_opp_id',
                                                                id_value : id_join,
                                                                id_group : g_id
                                                        },
                                                        type   : 'POST',
                                                        url    : ajaxurl,
                                                        success: function(html, data) { 
                                                            //alert( html );
                                                        }
                                          });
                                       
                                   }
                           });  
       
         });
        </script>      
        
        
        <div id="pweblinks-list">
           <form method="post">
              
              <input id="delete_submit" class="delete-by-checked" type="submit" name="delete_pl_pd_opp" value="Delete" />
              
              <table id="list-table">
                  <tbody>
                  <tr>
                      <?php
                        if( is_array($label)){
                            
                            foreach($label as $label_key => $label_var ){

                              if( is_string($label[$label_key]) ){  
                      ?>      
                                  <td class="label"><label><?php echo $label[$label_key]; ?></label></td>
                                  
                      <?php   
                              }
                           }
                        }
                      ?>
                  </tr>
                 
                  <?php $query = PL_pd_opp_Query::Query( 'g_position', 'pl_pd_opp' ); ?> 
                  <?php
                        if(!empty($query)){
                            
                            $count_val = 0;
                            
                            foreach( $query as $query_key => $query_var ){
                                 
                                 if( $count_val % 2 == 0 ){
                                     $class_label = 'is_atr';
                                 } else {
                                     $class_label = 'not_atr'; 
                                 }
 
                                 if( is_object( $query_var) ){
                                    
                                 $id = intval( $query_var->id );   
                  ?>                  
                                     
                                     <tr class="<?php echo $class_label; ?> sort_tr">
                                        <td class="result-checkbox"><input type="checkbox" class="delete_selected" id="delete_selected" name="delete_selected[]" value="<?php echo $id; ?>"/></td>
                                        <td class="result"><a href="admin.php?page=PL_PD_OPP_add&&pd_opp=<?php echo $id; ?>" class="pl-name-link"><?php echo !empty( $query_var->name ) ? $query_var->name : 'NA'; ?></a></td>
                                        <td class="result"><?php echo !empty( $query_var->cost ) ? $query_var->cost : 'NA'; ?></td>
                                        <td class="result"><div class="image_wrap"><img src="<?php echo $query_var->img; ?>" /></div></td>
                                        
                                        <td class="result sort_class">
                                            <span class="sortupdate">
                                                <input type="hidden" id="sort_id" class="sort_id" name="sort_id" value="<?php echo intval( $id ); ?>" />
                                                <input type="hidden" id="g_id" class="g_id" name="g_id" value="<?php echo intval( $id ); ?>" />
                                            </span>
                                        </td>
                                        
                                        <td class="result"><a href="admin.php?page=PL_PD_OPP_add&&pd_opp=<?php echo $id; ?>" class="edit-icon"></a></td>
                                        
                                     </tr>   
                            <?php             
                                     }
                                                    
                                     $count_val++;
                                }
                                
                            }   
                            ?>
                </tbody>
              </table>
                       
           </form>
        </div>