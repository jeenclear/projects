<?php

class PL_pd_opp_Bootstrap{
     
     public function __construct() {
        
	     define('PL_PD_OPP', 'PD OPP');
         add_action( 'admin_menu', array($this, 'pl_pd_opp_menu' ) );
         add_action('admin_enqueue_scripts', array( $this, 'pl_pd_opp_media_scripts' ) ); 
         wp_enqueue_script( 'jquery');
         
         pl_pd_opp_Loader::pl_pd_opp_database();
             
          if( is_admin()){
             
             wp_enqueue_script('admin_scripts_pl_pd_opp',  plugins_url( '/pl_pd_opp/js/backend.js' ) );
             wp_enqueue_style('admin_styles_pl_pd_opp',  plugins_url( '/pl_pd_opp/css/backend.css' ) );
             
             wp_enqueue_script('jquery-ui-sortable');
             wp_enqueue_script('jquery-ui-draggable');
             wp_enqueue_script('jquery-ui-droppable');
             
          }else{
            
             wp_enqueue_style( 'front_styles_pl_pd_opp', plugins_url(  '/pl_pd_opp/css/frontend.css' ) );

          }   
          
          // shortode   
         add_action( 'admin_init', array($this, 'pl_pd_opp_action_query') );        
         add_shortcode('PL_PD_OPP', array($this, 'pl_pd_opp_shortcode_ui') );
         
         // Filter
         add_filter('widget_text', 'do_shortcode');  
         
          /******************** Ajax Update PL_PD_OPP *****************************/
         add_action( 'wp_ajax_my_ajax_update_pl_pd_opp', array($this, 'my_ajax_update_pl_pd_opp' ) );
         add_action( 'wp_ajax_nopriv_my_ajax_update_pl_pd_opp', array($this, 'my_ajax_update_pl_pd_opp') );
         
          /******************** Ajax Update Sort *****************************/
         add_action( 'wp_ajax_my_ajax_sort_update_pl_pd_opp_id', array($this, 'my_ajax_sort_update_pl_pd_opp_id' ) );
         add_action( 'wp_ajax_nopriv_my_ajax_sort_update_pl_pd_opp_id', array($this, 'my_ajax_sort_update_pl_pd_opp_id') );
   	 }
     
    public function pl_pd_opp_menu(){  
       add_menu_page( PL_PD_OPP, PL_PD_OPP, 'manage_options', 'PL_PD_OPPmanager', array($this, 'PL_PD_OPP_manage' ), plugins_url( 'pl_pd_opp/images/icon-16.png' ) );   
       add_submenu_page( 'PL_PD_OPPmanager', __( 'Add New', 'PL_PD_OPP_add' ), __( 'Add New', 'PL_PD_OPP_add' ), 'manage_options', 'PL_PD_OPP_add', array( $this, 'PL_PD_OPP_add' ) ); 
    }
    
    public function pl_pd_opp_media_scripts(){
       wp_enqueue_media();
       wp_enqueue_script( 'media-upload' );
       wp_enqueue_script( 'thickbox' );
    }
    
    public function PL_PD_OPP_manage(){
        PL_PD_OPP_Loader::manage_pl_pd_opp();
    }
    
    public function PL_PD_OPP_add(){
        PL_pd_opp_Loader::add_new_pl_pd_opp();
    }
    
    public function pl_pd_opp_shortcode_ui(){
        require PL_PD_OPP_SHORTCODE . '/pl_pd_opp_shortcode.php';
        return PL_PD_OOPP_Shortcode_ui::pl_pd_opp_shortcode();
    }
    
    public function pl_pd_opp_action_query(){
        PL_pd_opp_Lib::insert_pl_pd_opp();
        PL_pd_opp_Lib::delete_pl_pd_opp();
    }
    
    public function my_ajax_update_pl_pd_opp(){
        PL_pd_opp_Lib::my_ajax_update_pl_pd_opp_tbl();   
    }
    
    public function my_ajax_sort_update_pl_pd_opp_id(){
        PL_pd_opp_Lib::my_ajax_sort_update_pl_pd_opp_sort();
    }   
    
}
?>