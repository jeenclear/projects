jQuery(function(){  
     
     /******************* Uploader ***********************/  
      var custom_uploader;

     jQuery('input#gallery_image_browse').live('click',function(e){
        e.preventDefault();
        if (custom_uploader) { custom_uploader.open();
            return;
        }

        custom_uploader = wp.media.frames.file_frame = wp.media({
                title: 'Gallery Type Image',
                button: {
                    text: 'Choose Image'
                },
                library: {
                      type: 'image'
                },
                multiple: false
        });
 
        custom_uploader.on('select', function() {
                attachment = custom_uploader.state().get('selection').first().toJSON();
                jQuery('input#gallery_image_text').attr( 'value', attachment.url );
                
                var src_name = jQuery('input#gallery_image_text').attr('value').split('/');
                var file     = src_name[src_name.length - 1];
                
                if( attachment.url ){
                    jQuery("div.gallery_image_display").fadeIn(200); 
                    jQuery("img#gallery_image_display_img").attr('src', attachment.url );
                    jQuery("span.gallery_image_display_label").text( file );
                }
        });

        custom_uploader.open();

     });  
     
      jQuery("span.gallery_image_display_remove").on('click',function(e){
        e.preventDefault();
        
        jQuery("input#gallery_image_text").attr("value", "");
        jQuery("img#gallery_image_display_img").attr("src", "");
        jQuery("span#gallery_image_display_label").text("");
        
        jQuery("div.gallery_image_display").fadeOut(200); 
     });
     /******************* Uploader ***********************/ 
     
       /******************* Uploader File ***********************/  
      var custom_uploader_file;

     jQuery('input#gallery_file_browse').live('click',function(e){
        e.preventDefault();
        if (custom_uploader_file) { custom_uploader_file.open();
            custom_uploader_file;
        }

        custom_uploader_file = wp.media.frames.file_frame = wp.media({
                title: 'Gallery Type File',
                button: {
                    text: 'Choose File'
                },
                multiple: false
        });
 
        custom_uploader_file.on('select', function() {
                attachment_file = custom_uploader_file.state().get('selection').first().toJSON();
                jQuery('input#gallery_file_text').attr( 'value', attachment_file.url );
                
                var src_name_file = jQuery('input#gallery_file_text').attr('value').split('/');
                var file_file     = src_name_file[src_name_file.length - 1];
                
                if( attachment_file.url ){
                    jQuery("div.gallery_file_display").fadeIn(200); 
                    jQuery("span.gallery_file_display_label").text( file_file );
                }
        });

        custom_uploader_file.open();

     });  
     
      jQuery("span.gallery_file_display_remove").on('click',function(e){
        e.preventDefault();
        
        jQuery("input#gallery_file_text").attr("value", "");
        jQuery("span#gallery_file_display_label").text("");
        
        jQuery("div.gallery_file_display").fadeOut(200); 
     });
     /******************* Uploader File ***********************/    
          
      jQuery('input#delete_all').live('click', function(){
          if( jQuery(this).is(':checked') ){  
                jQuery('input.delete_selected').attr('checked', true);
                var num_check = jQuery('input.delete_selected:checked').length; 
                jQuery('input#delete_submit').attr('value', 'Delete - ' + num_check );
          } else {
                jQuery('input.delete_selected').attr('checked', false); 
                jQuery('input#delete_submit').attr('value', 'Delete' );
          }
     });
     
      jQuery('input.delete_selected').live('click', function(){
          var num_check = jQuery('input.delete_selected:checked').length;          
          if( num_check != 0 ){
             jQuery('input#delete_submit').attr('value', 'Delete - ' + num_check );
          } else {
             jQuery('input#delete_submit').attr('value', 'Delete' );
          }  
     });
     
});      