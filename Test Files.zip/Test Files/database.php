<?php if( !class_exists('Database') ){

           class Database{
                 
                 public static function createDatabase(){
                       
                        $con = mysql_connect('localhost', 'root', '');
                        if ( !$con ) {
                            die('Could not connect: ' . mysql_error());
                        }
                        
                        $sql = 'CREATE DATABASE my_db';
                        
                        if ( mysql_query( $sql, $con ) ) {
                             echo "Database my_db created successfully";
                        } else {
                             //echo 'Error creating database: ' . mysql_error() . "";
                        }
                        
                        self::createTable( $con );
                       
                 }
                 
                 public static function createTable( $con ){
                        
                        $sql = 'CREATE TABLE users( '.
                               'id INT NOT NULL AUTO_INCREMENT, '.
                               'name VARCHAR(20) NOT NULL, '.
                               'primary key ( id ))';
                        
                        mysql_select_db( 'my_db' );
                        
                        if ( mysql_query( $sql, $con ) ) {
                             echo "Table users created successfully";
                        } else {
                             //echo 'Error creating Table: ' . mysql_error() . "";
                        }
                         
                 }
                 
                 public static function insertData($value=null){
                        
                        $name_val = $value;
                        $err      = null;
                        
                        if( !empty( $name_val ) ){
                        
                            $sql = "INSERT INTO users (name) VALUES ('".$name_val."')";
                            
                            $insert = mysql_query( $sql );
                            if( $insert > 0 ){
                                $err = $name_val . " is successfully added to the database ."; 
                            }

                        }
                        
                        return $err;
                        
                 }
                  
                 
           }
              
}
?>