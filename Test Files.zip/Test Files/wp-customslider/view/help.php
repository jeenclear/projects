<?php

/**
 * @author charly capillanes
 * @copyright 2016-2017
 */

$userdata = get_userdata( get_current_user_id() );

?>

<div id="wp-mvc__wrap">
    <?php
        echo 'Hello World!';
    ?>
</div>

