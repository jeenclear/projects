jQuery( function() { 
        // scripts
    }
);  