jQuery( function() 
    {
        // scripts
    }
);