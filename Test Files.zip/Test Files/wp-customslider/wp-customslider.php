<?php

/*
Plugin Name: WP Custom Slider ( Wordpress Model View Controller )
Description: Based Plugin Structure
Version: 1.1
Author: Plonta Creative
Author URI: http://plontacreative.com/
*/

include_once ( 'register.php' );

reqister_wp_customslider();