<?php
   session_start();
   require_once "../lib/dbcon_class.php";
   require_once "../lib/function_class.php";

   $dbcon = new dbcon();
   $lib   = new lib();
   $dbcon->dbconnect('localhost', 'root', '', 'custom');

   $action = $lib->get('action');

    switch($action){
        
     case'view':
       $left = "../includes/nav.php";
       $right = "view.php";
     break;
     
     case'delete':
        $left="../includes/nav.php";
        $right="delete.php";
      break;
      
      case'delete_all';
        $left="../includes/nav.php";
        $right="delete_all.php";
      break;
      case'modify':
        $left="../includes/nav.php";
        $right="modify.php";
      break;

      case'list':
           $left = "../includes/nav.php";
           $right = "list.php";
      break;

      case'logout':
         unset($_SESSION['user']);
         unset($_SESSION['pass']);

         $lib->direct_header('../index.php');
      break;

      default:
       $left = "../includes/nav.php";
       $right = "add.php";
    }



    include_once"../includes/template.php";
?>

