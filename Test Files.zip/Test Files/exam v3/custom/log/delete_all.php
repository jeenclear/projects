<?php
 
   $sql = "SELECT * FROM profilepix";
      $query = mysql_query($sql)or die(mysql_error());

      if($dbcon->dbNumFetch(1, $query)>0){
      while($result = $dbcon->dbNumFetch(2, $query)){
      extract($result);

      unlink($img_file);
 
    }
   } 
 
 $sql ="DELETE FROM phonebook";
 $result = $dbcon->dbQuery($sql);
 
 $sql2 ="DELETE FROM profilepix";
 $result2 = $dbcon->dbQuery($sql2);
 
 
 $lib->direct_header('index.php?action=list');
?>