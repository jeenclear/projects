
<?php
  $msg = '';
  $file = array(
               1 => 'file',
               2 => 'file',
               3 => '',
               4 => '',
               5 => ''
               );
               
  $submit = array(
               1 => 'submit',
               2 => 'sub',
               3 => 'Upload',
               4 => '',
               5 => ''
               );             
      
?>

<?php
    $lib->form_open(3);
 ?>
 
   <div class="upload_profile">
      <span class="upload_profile_file"><?php $lib->input_open($file); ?></span>
      <span class="upload_profile_submit"><?php $lib->input_open($submit); ?></span>
   </div>
   
 </form>  