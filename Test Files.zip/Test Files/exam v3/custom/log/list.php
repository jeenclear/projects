<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
</head>

<script>
  function modify(id)
  {
    window.location.href="index.php?action=modify&id=" + id;
  }

   function delete_phone(id)
   {
	if (confirm('Are you sure, you want to delete this information?')) {
		window.location.href = 'index.php?action=delete&id=' + id;
	}
   }
   
   function delete_all()
   {
    if(confirm('Are you sure, you want to remove all information?')){
        window.location.href = 'index.php?action=delete_all';
    }
   }
   
   function view(id)
    {
     window.location.href = "index.php?action=view&id=" + id; 
   }
</script>

<body>

<table border="0" class="phone_list" style="border:1px solid gray;" cellpadding="0" cellspacing="0">
 <tr>
   <td style="border-right:1px solid silver; background-color:gray; width:50px; text-align:center;">id</td>
   <td style="border-right:1px solid silver; background-color:gray; width:50px; text-align:center;">Image</td>
   <td style="border-right:1px solid silver; background-color:gray; width:100px; text-align:center;">Name</td>
   <td style="border-right:1px solid silver; background-color:gray; width:100px; text-align:center;">Email</td>
   <td style="border-right:1px solid silver; background-color:gray; width:100px; text-align:center;">Phonebook</td>
	<?php
		if(isset($_SESSION['user'])){
		
		if( $result_session['role'] == 'admin') {
	?>
		<td style="border-right:1px solid silver; background-color:gray; width:50px; text-align:center;">Modify</td>
		<td style="border-right:1px solid silver; background-color:gray; width:50px; text-align:center;">Delete</td>
	<?php 
			}
		}else{}
	?>
     
 </tr>

 <?php
      $count_user = '';
      $sql = "SELECT * FROM phonebook";
      $query = $dbcon->dbQuery($sql);

      if($dbcon->dbNumFetch(1, $query)>0){
      while($result = $dbcon->dbNumFetch(2, $query)){
      extract($result);
      $count_user[] = $name;
	  
	  $sql_profile = "SELECT * FROM profilepix WHERE id = '". $id ."'";
      $query_profile = $dbcon->dbQuery($sql_profile);
	  $result_profile = $dbcon->dbNumFetch(2, $query_profile);
 ?>


 <tr>
   <td style="border-bottom:1px solid gray;border-right:1px solid gray; text-align:center;"><?php print $id; ?></td>
   
   <td style="border-bottom:1px solid gray;border-right:1px solid gray;text-align:center;">
   <?php 
	if(isset($_SESSION['user'])) { 
		$dir_tag = '..';
	}else{
		$dir_tag = '.';
	}
   ?>
	<img src="<?php print $dir_tag.$result_profile['image']; ?>" width="150px" height="150px"/>
   
   </td>
   <td style="border-bottom:1px solid gray;border-right:1px solid gray;text-align:center;">
   <a href="javascript:view(<?php print $id; ?>);"><?php print $name; ?></a>
   </td>
   <td style="border-bottom:1px solid gray;border-right:1px solid gray;text-align:center;"><?php print $email; ?></td>
   <td style="border-bottom:1px solid gray;border-right:1px solid gray;text-align:center;"><?php print $phone; ?></td>
  
    <?php
      if(isset($_SESSION['user'])){
		
		if( $result_session['role'] == 'admin') {
    ?>
    <td style="font-size:10px; border-bottom:1px solid gray;border-right:1px solid gray;text-align:center;">
    <a href="javascript:modify(<?php print $id; ?>);">Modify</a>
    </td>
  
   <td style="font-size:10px; border-bottom:1px solid gray;border-right:1px solid gray;text-align:center;">
   <a href="javascript:delete_phone(<?php print $id; ?>);">Delete</a>
    </td>
    <?php
		}
       }else{}
     ?>
  
 </tr>

 <?php
   }
  }
 ?>
</table>

<?php
  if(isset($_SESSION['user'])) {
?>

  <?php
    if($count_user != 0){
      $counter_num = $lib->counter_string($count_user, 2);  
    }else{
      $counter_num = '';    
    }
    
    if($counter_num){
  ?>
  
   <div class="delete_all"><a href="javascript:delete_all();">Delete all</a></div>
  
   <?php
    }else{
      print '';   
    }    
   ?> 
   
<?php
  }else{
     print'';
  }
?>
</body>

</html>