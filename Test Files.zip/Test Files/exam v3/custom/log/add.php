<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
</head>

<script>
 function checkNumber(textBox)
{
	while (textBox.value.length > 0 && isNaN(textBox.value)) {
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)
	}
	textBox.value = trim(textBox.value);
}
</script>


<body>

<?php
   $msg = '';
   
	$file = array(
		1 => 'file',
		2 => 'file',
		3 => '',
		4 => '',
		5 => ''
	);
   
	$Name = array(
		1=>'text',
		2=>'name',
		3=>$lib->form_method(1, 'name'),
		4=>'',
		5=>''
	);
	
	$Email = array(
		1=>'text',
		2=>'email',
		3=>$lib->form_method(1, 'email'),
		4=>'',
		5=>''
	);

	$phone_number = array(
		1=>'text',
		2=>'phone',
		3=>$lib->form_method(1, 'phone'),
		4=>'',
		5=>'onKeyUp="checkNumber(this);"'
	);
	
	$user = array(
		1=>'text',
		2=>'user',
		3=>$lib->form_method(1, 'user'),
		4=>'',
		5=>''
	);
	
	$pass = array(
		1=>'password',
		2=>'pass',
		3=>$lib->form_method(1, 'pass'),
		4=>'',
		5=>''
	);

	$submit = array(
		1=>'submit',
		2=>'sub',
		3=>'Add',
		4=>'',
		5=>''
	);
	
	$select_value = array(
		"name" => "userrole",
		"class" => "userrole"
	);
	
	$option_array = array(
		"admin" => "Administrator",
		"user" => "User",
		"guest" => "Guest",
	);	
?>

<?php
  $lib->form_open(3);
?>

<table border="0" style="width:250px; margin:auto; height:200px; background-color:blue;">
 <tr>
   <td colspan="2">Upload Profile Pix</td>
 </tr>
 <tr>
   <td colspan="2"><?php $lib->input_open($file); ?></td>
 </tr>
 
 <tr>
  <td style="color:white;">Firstname:</td>
  <td><?php $lib->input_open($Name); ?></td>
 </tr>

 <tr>
  <td style="color:white;">Email:</td>
  <td><?php $lib->input_open($Email); ?></td>
 </tr>

 <tr>
  <td style="color:white;">Phone #:</td>
  <td><?php $lib->input_open($phone_number); ?></td>
 </tr>
 
  <tr>
  <td style="color:white;">Role:</td>
  <td><?php print $lib->select_open( $select_value, $option_array ); ?></td>
 </tr>

 <tr>
  <td style="color:white;">User:</td>
  <td><?php $lib->input_open($user); ?></td>
 </tr>

 <tr>
  <td style="color:white;">Password:</td>
  <td><?php $lib->input_open($pass); ?></td>
 </tr>

 <tr>
  <td align="center" colspan="2"><?php $lib->input_open($submit); ?></td>
 </tr>
</table>

<?php
  
  if($lib->form_method(1, 'sub')){ 
  if(!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['phone'])){
  if(is_numeric($_POST['phone'])){
	

   $query_id = $dbcon->dbQuery_("select max(id) from phonebook");
       $id_row = $dbcon->dbNumFetch(2, $query_id);
        if($id_row[0]==""){
         $id = 1;
        }else{
          $id = $id_row[0]+ 1;
        }
         
		if($_FILES['file']['name'] != ''){
		  
        $yourfile = $_FILES['file']['name'];
        $filedes = array(
                "CompuServe GIF Image",
                "JPEG Image",
                "Portable Network Graphics (PNG) Image"
                );

         $fileext = array(".gif",".jpg",".png");
         $ext = strrchr($yourfile,'.');
         if (in_array($ext,$fileext)) {
                $ext2 = array_search($ext, $fileext);
                $msg = $filedes[$ext2].$lib->error_messages(4);
                
        $dir_save = "/profilepix/".mktime().$_FILES['file']['name'];         
        $dir = "../profilepix/".mktime().$_FILES['file']['name'];    	  
        move_uploaded_file($_FILES['file']['tmp_name'], $dir);
		
		$exists = $lib->form_method(1, 'user');
		
		$sql3 = "SELECT * FROM phonebook WHERE username='{$exists}'";
		$query3 = $dbcon->dbQuery($sql3);
		$result3 = $dbcon->dbNumFetch(1, $query3);
		
		 if ( $result3 == 0 ) {
          
			$sql = "INSERT INTO  profilepix VALUE('".$id."','".$dir_save."')";                               
			$result = $dbcon->dbQuery($sql);
			 
			$sql2 = "INSERT INTO phonebook VALUE('".$id."',
												'".$lib->form_method(1, 'name')."',
												'".$lib->form_method(1, 'email')."',
												'".$lib->form_method(1, 'phone')."',
												'".$lib->form_method(1, 'userrole')."',
												'".$lib->form_method(1, 'user')."',
												'".md5($lib->form_method(1, 'pass'))."')";
			$result2 = $dbcon->dbQuery($sql2);

			$lib->direct_header('index.php?action=list');
		
		}else{
         $msg = $lib->error_messages(5);
      }
	  
      }else{
         $msg = $lib->error_messages(3);
      }
      
      }else{
        $msg = $lib->error_messages(2); 
     }
     
      }else{
       $msg = $lib->error_messages(1);
     }  

   }else{
     $msg = $lib->error_messages(0);
   }
          
  }
    
?>

</form>

 <div class="error_msg">
     <?php
         if($msg!=''){
           print $msg;
        }
     ?>
   </div>

</body>

</html>