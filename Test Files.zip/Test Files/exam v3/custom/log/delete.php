<?php
 
    $sql = "SELECT * FROM profilepix WHERE id = '".$lib->_get('id')."'";
      $query = mysql_query($sql)or die(mysql_error());

      if($dbcon->dbNumFetch(1, $query)>0){
      while($result = $dbcon->dbNumFetch(2, $query)){
      extract($result);

      unlink($img_file);
 
    }
   } 

 $sql ="DELETE FROM phonebook WHERE id='".$lib->_get('id')."'";
 $result = $dbcon->dbQuery($sql);
 
 $sql2 ="DELETE FROM profilepix WHERE id='".$lib->_get('id')."'";
 $result2 = $dbcon->dbQuery($sql2);

  $lib->direct_header('index.php?action=list');
 ?>
 