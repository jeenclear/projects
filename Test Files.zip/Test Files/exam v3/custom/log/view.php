<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Exam</title>
</head>

<script>
 function checkNumber(textBox)
{
	while (textBox.value.length > 0 && isNaN(textBox.value)) {
		textBox.value = textBox.value.substring(0, textBox.value.length - 1)
	}
	textBox.value = trim(textBox.value);
}
</script>

<body>

<?php
    $msg = '';
      $sql = "SELECT * FROM phonebook WHERE exam_id = '".$lib->_get('id')."'";
      $query = mysql_query($sql)or die(mysql_error());

      if($dbcon->dbNumFetch(1, $query)>0){
      while($result = $dbcon->dbNumFetch(2, $query)){
      extract($result);
 ?>
 
  

<table border="0" style="width:300px; height:200px; margin:auto; background-color:blue;">
  <tr>
   <td colspan="2">View Account</td>
 </tr>
    <?php
     $sql = "SELECT * FROM profilepix WHERE exam_id = '".$lib->_get('id')."'";
      $query = mysql_query($sql)or die(mysql_error());

      if($dbcon->dbNumFetch(1, $query)>0){
      while($result = $dbcon->dbNumFetch(2, $query)){
      extract($result);
    ?>
 <tr>
   <td colspan="2"><img src="<?php print $img_file; ?>" width="150px" height="150px"/></td>
 </tr>
 
   <?php
     }
    } 
   ?>

 <tr>
  <td style="color:white;">Name:</td>
  <td><?php print $exam_name; ?></td>
 </tr>

 <tr>
  <td style="color:white;">Email:</td>
  <td><?php print $exam_email; ?></td>
 </tr>

 <tr>
  <td style="color:white;">Phone #:</td>
  <td><?php print $exam_phone; ?></td>
 </tr>

</table>

</form>

<?php
  }
 }
?>
</body>

</html>