<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
</head>

<body>


<?php
   $msg = '';
   $user_name = array(
                      1=>'text',
                      2=>'user',
                      3=>$lib->form_method(1, 'user'),
                      4=>'',
                      5=>''
                     );

   $pass_word = array(
                      1=>'password',
                      2=>'pass',
                      3=>$lib->form_method(1, 'pass'),
                      4=>'',
                      5=>''
                     );

   $submit = array(
                      1=>'submit',
                      2=>'sub',
                      3=>'login',
                      4=>'',
                      5=>''
                     );

?>


<?php
    $lib->form_open(1);
 ?>

<table border="0" align="center" style='background-color:blue; border:1px solid silver;height:150px;width:300px;'>
 <tr>
  <td style="font-size:12px; color:white;">Username:</td>
  <td><?php $lib->input_open($user_name); ?></td>
 </tr>

 <tr>
  <td style="font-size:12px; color:white;">Password:</td>
  <td><?php $lib->input_open($pass_word); ?></td>
 </tr>

 <tr>
  <td colspan="2" align="center"><?php $lib->input_open($submit); ?></td>
 </tr>

</table>

<?php

    if($lib->form_open(1, 'sub')){
    if(!empty($lib->form_method(1, 'pass')) && !empty($lib->form_method(1, 'pass'))){
	    
	  $sql_login = "SELECT * FROM phonebook WHERE username = '". $lib->form_method(1, 'user') ."' AND password ='". md5( $lib->form_method(1, 'pass') ) ."'";
      $query_login = $dbcon->dbQuery($sql_login);
	  $login = $dbcon->dbNumFetch(2, $query_login);

	  if( isset( $login ) and !is_null( $login[0]) ) { 
	  
	   $_SESSION['user'] = $lib->form_method(1, 'user');
       $_SESSION['password'] = $lib->form_method(1, 'pass');

       $lib->direct_header('log/index.php');
	   
		} else {
			$msg = "Username or Password is invalid";
		}
		}else{
			$msg = 'Pls. Enter your correct username and password.';
		} 
	} 

?>


  <div class="error_msg">
     <?php
        if($msg!=''){
           print $msg;
        }
     ?>
   </div>
</form>
</body>

</html>