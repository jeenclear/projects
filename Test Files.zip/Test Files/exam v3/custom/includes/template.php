<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Custom</title>
  <link rel="stylesheet" type="text/css" href="../css/style.css">
</head>

<body>

<div id="header">
  <h1>Custom</h1>
</div>

<div id="content">
  <div class="right_side">
    <?php
	
	if(isset($_SESSION['user'])) {
		
		$sql_session = "SELECT * FROM phonebook WHERE username = '". $_SESSION['user'] ."'";
		$query_session = $dbcon->dbQuery($sql_session);
		$result_session = $dbcon->dbNumFetch(2, $query_session);	
		
		$user = $result_session['role'];
		print "Hi,".$user;
	
	}

    include_once $left;
    ?>
  </div>
  <div class="left_side">
    <?php
      include_once $right;
    ?>
  </div>
</div>

</body>

</html>