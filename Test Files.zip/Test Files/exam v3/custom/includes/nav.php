<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Hello!</title>
  <link rel="stylesheet" type="text/css" href="css/style.css">    
</head>

<body>

<div id="nav_wrap">

 <?php
	if(isset($_SESSION['user'])) {
 ?>
    
    <a href="index.php" class="nav">Add</a>
    <a href="index.php?action=list" class="nav">List</a>
    <a href="index.php?action=logout" class="nav">Logout</a>

   <?php
     }else{
   ?>

    <a href="index.php" class="nav">Sign-In</a>
    <a href="index.php?action=list" class="nav">List</a>

   <?php
     }
   ?>

</div>

</body>

</html>