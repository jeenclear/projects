<?php
   class dbcon{

     private $host;
     private $user;
     private $pass;
     private $dbname;

     public function dbconnect($host, $user, $pass, $dbname){
     global $dbcon;
     $this->host = $host;
     $this->user = $user;
     $this->pass = $pass;
     $this->dbname = $dbname;

      $this->con = mysql_connect($this->host, $this->user, $this->pass)
                                 or die('dbconnect'.mysql_error());

      $this->sel = mysql_select_db($this->dbname)
                                   or die('dbselect'.mysql_error());

       return $this->con.$this->sel;
     }

      function dbQuery($query){
      global $dbcon;
      $this->query = $query;
      $this->result = mysql_query($this->query) or die('dbquery'.mysql_error());

      return $this->result;
      }

      function dbQuery_($query){
      global $dbcon;
      $this->query = $query;
      $this->result = mysql_query($this->query);

      return $this->result;
      }

     public function dbNumFetch($x, $param){
     global $dbcon;
     $this->x = $x;
     $this->param = $param;

     switch($this->x){

      case 1:
      return mysql_num_rows($this->param);
      break;

      case 2:
      return mysql_fetch_array($this->param);
      break;

      default:
      return $this->x.$this->param;

      }
     }

   }
?>