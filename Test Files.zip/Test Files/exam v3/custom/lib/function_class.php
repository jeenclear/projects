<?php
    class lib{

      public function _post($n){
       global $lib;
        return isset($_POST[$n]) ? ($_POST[$n]) : "";
      }

      public function _get($id){
      global $lib;
        return isset($_GET[$id]) ? ($_GET[$id]) : "";
      }

      public function get($action){
      global $lib;
      $this->action = $action;
      $this->get = (isset($_GET[$this->action]) && $_GET[$this->action]!='') ? $_GET[$this->action]:'';

       return $this->get;
      }


  public function input_open($array){
  global $lib;
  $this->array = $array;
  $input_var = "<input type='".$this->array[1]."'
                      name='".$this->array[2]."'
                      value='".$this->array[3]."'
                      style='".$this->array[4]."'
                      ".$this->array[5]."
               >";
               
  return print $input_var;           
  }
  
  public function select_open( $array = array(), $option = array() ) {
	global $lib;
	
	$select_var = "";
	$select_var .= "<select name=".$array['name']." class=". $array['class'] .">";
	
	/* Example arraay
	$wcr=array(
	 "ANG" = > 'Angola',
	 "ANB" = > 'Antigua & Barbuda',
	 "ARM" = > 'Armenia',
	  );
	*/
	
	$selected_val = "";
	
	foreach($option as $p => $w) {
		
	   $selected_val = $p == $lib->form_method(1, $array['name']) ? ' selected' : false;

	   $select_var .= '<option '. $selected_val .' value="'.$p.'">'.$w.'</option>';
	
	}
	
	$select_var .= "</select>";
	
	return $select_var;
  }
  
   /** ----------- 
        form function class start------------------- 
   **/
   public function form_method($x, $num){
    global $lib;
    $this->x = $x;
    $this->num = $num;
    $this->post_get = array(
                           1=>isset($_POST[$this->num]) ? ($_POST[$this->num]):"",
                           2=>isset($_GET[$this->num]) ? ($_POST[$this->num]):""
                           );

    switch($this->x){

      case 1:
      return $this->post_get[1];
      break;

      case 2:
      return $this->post_get[2];
      break;

      default:
      return $this->x.$this->num.$this->post_get[1].$this->post_get[2];

    }
   }

   public function form_open($x){
   global $lib;
   $this->x = $x;
   $this->form_array = array(1=>'POST', 2=>'GET', 3=>'POST');

     switch($this->x){

       case 1:
       $return = "<form method='".$this->form_array[1]."'>";
       break;

       case 2:
       $return = "<form method='".$this->form_array[2]."'>";
       break;
       
       case 3:
       $return = "<form method='".$this->form_array[3]."' enctype='multipart/form-data'>";
       break;

       default:
       $return = $this->x.$this->form_array[1].$this->form_array[2].$this->form_array[3];
     }
     
     return print $return;
   }
   
      /*-----------form function class end-------------------*/

   public function direct_header($url){
       global $lib;
       $this->url = array(1=>$url ? $url:"");
       if(!headers_sent()){
          header('Location:'.$this->url[1].'');
        }else{
          print"<script>window.location.href='".addslashes($this->url[1])."'</script>";
        }
          print"<script>window.location.href='".addslashes($this->url[1])."'</script>";
       }
       
   public function counter_string($user, $count){
       global $lib;
       $this->num = count($user) >= $count;
       return $this->num;
   }
   
   public function error_messages($num){
   global $lib;
   $this->error_message = array(
                         "Enter your information.",
                         "Pls. input a number only.",
                         "Pls choose you profile picture.",
                         "Unknown file type.",
                         "<br/>Successfully Saved.",
						 "Username Already Exist."
                         );
                         
                         
    return $this->error_message[$num];                     
   }
   
   public function edit_error_messages($num){
   global $lib;
   $this->edit_error_message = array(
                         "Empty field blank.",
                         "Pls. input a number only in phone.",
                         "Pls choose you profile picture.",
                         "Unknown file type.",
                         "<br/>Successfully Updated."
                         );
                         
                         
    return $this->edit_error_message[$num];                     
   }

   }
?>