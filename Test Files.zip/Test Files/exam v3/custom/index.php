<?php
   session_start();
   require_once "lib/dbcon_class.php";
   require_once "lib/function_class.php";

   $dbcon = new dbcon();
   $lib   = new lib();
   $dbcon->dbconnect('localhost','root','','custom');

   $action = $lib->get('action');

    switch($action){

      case'list':
        $left="includes/nav.php";
        $right="log/list.php";
      break;

      default:
       $left = "includes/nav.php";
       $right = "includes/login.php";
    }

    include_once"includes/template.php";
?>

