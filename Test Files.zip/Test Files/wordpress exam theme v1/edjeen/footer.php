		<div class="footer-wrapper">
			<div class="footer-pad">
			<?php 
				echo sprintf( __( '%1$s %2$s %3$s. All Rights Reserved.', 'edjeen' ), '&copy;', date( 'Y' ), esc_html( get_bloginfo( 'name' ) ) ); 
			?>
			</div>
		</div>
	</div><!-- /outer-pad -->
</div><!-- /outer-wrapper -->